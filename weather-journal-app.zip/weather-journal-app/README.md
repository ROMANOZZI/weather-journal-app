# Weather-Journal App Project

## Overview
 This code is about making a weather journal app
 
 *  used the starter code from https://github.com/udacity/fend/tree/refresh-2019
 *  used Node.js in running the server.js locally
 * installed (express,cors,body-parser)
 * setup the server side code
 * and adding get and post routes 
 * got the api key from https://openweathermap.org/
 * used get and post requests to show the Api data
 * Added another section to get and show the feeling input from user 
 * some strings to explain the data by editing HTML
 * Added some styles by css


