// Setup empty JS object to act as endpoint for all routes
projectData = {};

// Require Express 
const express = require('express');
const app = express();
// Middleware//
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
//cross origins allowance
const cors = require('cors');
app.use(cors());

// Initialize the main project folder
app.use(express.static('website'));
const port = 3000;

//Spin up the server
const server = app.listen(port, Running);

// Callback to debug
function Running(){
    console.log('server is running');
    console.log(`server is running on localhost: ${port}`);
};

//GET route 
app.get('/all', sendingFunc)

function sendingFunc (request, response) {
    response.send(projectData)
}

// POST route
app.post('/addWeatherData', PostingFunc)

function PostingFunc(request, response) {
    projectData.temperature = request.body.temperature;
    projectData.date = request.body.date;
    projectData.user_response = request.body.user_response;
    response.end();
    console.log(projectData)
}