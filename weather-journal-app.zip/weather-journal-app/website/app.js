// getting Date
let today = new Date();
const dd = String(today.getDate()).padStart(2, '0');
const mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
const yyyy = today.getFullYear();
newDate = mm + '.' + dd + '.' + yyyy;


// API key from OpenWeatherMap.org
let Apikey = 'd89a2d085a9de66a7168db8d4c52c58f&units=metric';


//Button section
const generate = document.getElementById("generate");
document.getElementById('generate').addEventListener('click', generateURL);
// create afunction generateURL to checking the button
function generateURL (e){
   
     
    let APiUrl = 'https://api.openweathermap.org/data/2.5/weather?zip=';
    const input = document.getElementById('feelings').value;
     const zip = document.getElementById('zip').value;

      getTemp( APiUrl , zip ,Apikey)
    .then(function (data){
       
        postFun('http://localhost:3000/addWeatherData', {temperature: data.main.temp, date: newDate, user_response: input } )
        .then(function() {
            UpdateUI()
        })
    })
}





// get request
async function getTemp(APiUrl, code, Apikey){
    
        let  NewURl = await fetch( 'https://api.openweathermap.org/data/2.5/weather?zip='+ code + ',us' + '&APPID=' + Apikey)
        console.log(NewURl);
        try {
            const data = await NewURl.json();
            
            console.log(data);
            return data;
        }
        catch (error) {

            console.log(`error: ${error}`);
        }
    }
    




// post request
async function postFun (url = '', data = {}) {
    // Configuring the post request to deal with json data and to work with `index.html`
    const request = await fetch(url, {
        method: "POST",
        credentials: "same-origin",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(data)
    });

    try {
        // returning back the new data

        const data= await request.json();
      
        return data;}

     catch (error) {

        console.log(`error: ${error}`);
    }
}




// Updating the UI
const UpdateUI = async () => {
    const request = await fetch('http://localhost:3000/all');
    try {
        const projectData = await request.json();
        
        document.getElementById('date').innerHTML = projectData.date;
        document.getElementById('temp').innerHTML = projectData.temperature;
        document.getElementById('inputFeeling').innerHTML = projectData.user_response;
    }
    catch (error) {

        console.log(`error: ${error}`);
    }
}